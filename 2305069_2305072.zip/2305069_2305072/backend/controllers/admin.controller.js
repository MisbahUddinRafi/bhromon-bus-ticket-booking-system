const pool = require('../src/db');

/* =========================
   Admin Dashboard
========================= */
exports.dashboard = async (req, res) => {
    const user = JSON.parse(req.headers['x-user']);
    res.json({ name: user.name });
};

/* =========================
   Get All Cities
========================= */
exports.getCities = async (req, res) => {
    const result = await pool.query(`SELECT city_id, city_name FROM CITY ORDER BY city_name`);
    res.json(result.rows);
};

/* =========================
   Get All Operators
========================= */
exports.getOperators = async (req, res) => {
    const result = await pool.query(`SELECT operator_id, operator_name FROM BUS_OPERATOR ORDER BY operator_name`);
    res.json(result.rows);
};

/* =========================
   Get All Users
========================= */
exports.getUsers = async (req, res) => {
    const result = await pool.query(`SELECT user_id, name, email, phone_number, role FROM USERS ORDER BY name`);
    res.json(result.rows);
};

/* =========================
   Get Available Buses for Operator on a Date
========================= */
exports.getAvailableBuses = async (req, res) => {
    const { operatorId, date } = req.params;

    // Get buses of this operator not scheduled on the given date
    const result = await pool.query(`
        SELECT bus_id, bus_number, bus_type 
        FROM BUS 
        WHERE operator_id=$1
        AND bus_id NOT IN (
            SELECT bus_id 
            FROM SCHEDULE 
            WHERE journey_date=$2
            AND schedule_status='active'
        )
        ORDER BY bus_number
    `, [operatorId, date]);

    res.json(result.rows);
};

/* =========================
   Create Schedule
========================= */
exports.createSchedule = async (req, res) => {
    const {
        sourceCityId,
        destinationCityId,
        journeyDate,
        departureTime,
        price,
        busId
    } = req.body;

    if (sourceCityId === destinationCityId)
        return res.status(400).json({ message: "Same cities not allowed" });

    if (price <= 0 || price > 5000)
        return res.status(400).json({ message: "Invalid price" });


    // using transaction to ensure route creation and schedule creation happen together
    const client = await pool.connect();

    try {
        await client.query('BEGIN');        // begin transaction

        // 1. Find or create route
        let route = await client.query(
            `SELECT route_id 
             FROM ROUTE 
             WHERE source_city_id=$1 
             AND destination_city_id=$2`,
            [sourceCityId, destinationCityId]
        );

        let routeId;

        if (route.rows.length === 0) {
            const newRoute = await client.query(
                `INSERT INTO ROUTE (source_city_id, destination_city_id)
                 VALUES ($1,$2)
                 RETURNING route_id`,
                [sourceCityId, destinationCityId]
            );
            routeId = newRoute.rows[0].route_id;
        } else {
            routeId = route.rows[0].route_id;
        }

        // 2. Insert schedule (Seats auto-created by DB trigger)
        await client.query(
            `INSERT INTO SCHEDULE 
            (journey_date, departure_time, price, schedule_status, bus_id, route_id)
            VALUES ($1,$2,$3,'active',$4,$5)`,
            [journeyDate, departureTime, price, busId, routeId]
        );

        await client.query('COMMIT');           // commit transaction

        res.json({ message: "Schedule Created Successfully" });

    } catch (err) {
        await client.query('ROLLBACK');         // rollback transaction on error

        // Handle duplicate bus schedule error
        if (err.code === '23505') {
            return res.status(400).json({
                message: "This bus is already scheduled at this date and time"
            });
        }

        console.error(err);
        res.status(500).json({ message: "Error creating schedule" });

    } finally {
        client.release();           // release client back to pool
    }
};


/* =========================
   Cancel Schedule
========================= */
exports.cancelSchedule = async (req, res) => {
    const scheduleId = req.params.id;

    // transaction management is necessary here 
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        await completeExpiredSchedules(client);   // ensure schedule statuses are up-to-date

        const lockResult = await client.query(
            `SELECT schedule_id FROM SCHEDULE
             WHERE schedule_id = $1 AND schedule_status = 'active'
             FOR UPDATE`,
            [scheduleId]
        );


        if (lockResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ message: "Schedule not found or already inactive" });
        }


        // call schedule cancel database function 
        // internally release all bookings and process 100% refunds (excluding service fee) for confirmed bookings
        // makes schedule status 'cancelled' and schedule_seat_status 'cancelled' 
        const result = await client.query(
            `SELECT cancel_schedule($1) AS result`,
            [scheduleId]
        );


        if (result.rows[0].result !== true) {
            await client.query('ROLLBACK');
            return res.status(404).json({ message: "Schedule not found or already inactive" });
        }

        await client.query('COMMIT');

        res.json({ message: "Schedule Cancelled Successfully" });


    } catch (err) {
        await client.query('ROLLBACK');
        console.error('Error cancelling schedule:', err.message, err.detail);
        res.status(500).json({ message: "Error cancelling schedule", error: err.message });
    } finally {
        client.release();
    }
};


/* =========================
   Get Active Schedules
========================= */

const completeExpiredSchedules = async (client = null) => {
    const queryClient = client || pool;
    await queryClient.query(`
        UPDATE SCHEDULE
        SET schedule_status = 'completed'
        WHERE schedule_status = 'active'
        AND (journey_date + departure_time) < NOW()
    `);
};


exports.getActiveSchedules = async (req, res) => {
    try {
        // First, mark past schedules as completed
        await completeExpiredSchedules();

        // Then fetch active schedules
        const result = await pool.query(`
            SELECT 
                s.schedule_id,
                c1.city_name AS source,
                c2.city_name AS destination,
                to_char(s.journey_date, 'YYYY-MM-DD') AS journey_date,
                s.departure_time,
                s.price,
                s.schedule_status,
                b.bus_number,
                b.bus_type,
                bo.operator_name
            FROM SCHEDULE s
            JOIN ROUTE r ON s.route_id = r.route_id
            JOIN CITY c1 ON r.source_city_id = c1.city_id
            JOIN CITY c2 ON r.destination_city_id = c2.city_id
            JOIN BUS b ON s.bus_id = b.bus_id
            JOIN BUS_OPERATOR bo ON b.operator_id = bo.operator_id
            WHERE s.schedule_status = 'active'
            ORDER BY s.journey_date, s.departure_time
        `);

        res.json(result.rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error fetching schedules" });
    }
};



/* =========================
    Get Past Schedules
========================= */
exports.getPastSchedules = async (req, res) => {
    try {

        // Make sure expired schedules are marked completed
        await completeExpiredSchedules();

        const result = await pool.query(`
            SELECT 
                s.schedule_id,
                c1.city_name AS source,
                c2.city_name AS destination,
                to_char(s.journey_date, 'YYYY-MM-DD') AS journey_date,
                s.departure_time,
                s.price,
                s.schedule_status,
                b.bus_number,
                b.bus_type,
                bo.operator_name
            FROM SCHEDULE s
            JOIN ROUTE r ON s.route_id = r.route_id
            JOIN CITY c1 ON r.source_city_id = c1.city_id
            JOIN CITY c2 ON r.destination_city_id = c2.city_id
            JOIN BUS b ON s.bus_id = b.bus_id
            JOIN BUS_OPERATOR bo ON b.operator_id = bo.operator_id
            WHERE 
                s.schedule_status IN ('completed', 'cancelled')
                OR (s.journey_date + s.departure_time) < NOW()
            ORDER BY s.journey_date DESC, s.departure_time DESC
        `);

        res.json(result.rows);

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error fetching past schedules" });
    }
};




/* =========================
   Get User Booking History
========================= */
exports.getUserHistory = async (req, res) => {
    try {

        await completeExpiredSchedules();   // ensure schedule statuses are up-to-date

        const result = await pool.query(`
            SELECT 
                b.booking_id, 
                b.booking_status, 
                s.schedule_status, 
                to_char(p.payment_time, 'DD-MM-YYYY HH24:MI:SS') AS payment_time,
                u.name AS user_name,
                to_char(s.journey_date, 'DD-MM-YYYY') AS journey_date,
                s.departure_time,
                bo.operator_name,
                bus.bus_number,
                c1.city_name AS source, 
                c2.city_name AS destination,
                p.payment_amount AS total_fare,
                p.payment_type AS payment_method,
                p.payment_reason, 
                (SELECT COUNT(*)::int FROM BOOKED_SEAT bs WHERE bs.booking_id = b.booking_id) AS total_seats_booked,
                COALESCE((
                    SELECT JSON_AGG(JSON_BUILD_OBJECT(
                        'seat_number', bs.seat_number, 
                        'name', bs.passenger_name, 
                        'gender', bs.passenger_gender))
                    FROM BOOKED_SEAT bs
                    WHERE bs.booking_id = b.booking_id 
                ), '[]'::json) AS passenger_info
            FROM BOOKING b
            JOIN USERS u ON b.user_id = u.user_id
            JOIN SCHEDULE s ON b.schedule_id = s.schedule_id
            JOIN BUS bus ON s.bus_id = bus.bus_id
            JOIN BUS_OPERATOR bo ON bus.operator_id = bo.operator_id
            JOIN ROUTE r ON s.route_id = r.route_id
            JOIN CITY c1 ON r.source_city_id = c1.city_id
            JOIN CITY c2 ON r.destination_city_id = c2.city_id
            LEFT JOIN PAYMENT p ON b.booking_id = p.booking_id
            WHERE b.user_id = $1 
            ORDER BY b.booking_time DESC
        `, [req.params.id]);

        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error fetching user history" });
    }
};

/* =========================
   Get Operator Schedule History
========================= */
exports.getOperatorHistory = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT 
                s.schedule_id,
                s.journey_date,
                s.departure_time,
                s.schedule_status,
                s.price,
                b.bus_number,
                b.bus_type,
                bo.operator_name,
                c1.city_name AS source_city,
                c2.city_name AS destination_city
            FROM SCHEDULE s
            JOIN BUS b ON s.bus_id = b.bus_id
            JOIN BUS_OPERATOR bo ON b.operator_id = bo.operator_id
            JOIN ROUTE r ON s.route_id = r.route_id
            JOIN CITY c1 ON r.source_city_id = c1.city_id
            JOIN CITY c2 ON r.destination_city_id = c2.city_id
            WHERE bo.operator_id = $1
            ORDER BY s.journey_date DESC, s.departure_time DESC
        `, [req.params.id]);

        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error fetching operator history" });
    }
};

/* =========================
   Get Schedule Details with Seat Information
========================= */
exports.getScheduleDetails = async (req, res) => {
    try {
        const scheduleId = req.params.scheduleId;

        // Get schedule details
        const scheduleResult = await pool.query(`
            SELECT 
                s.schedule_id,
                s.journey_date,
                s.departure_time,
                s.schedule_status,
                s.price,
                b.bus_number,
                b.bus_type,
                bo.operator_name, 
                c1.city_name AS source_city,
                c2.city_name AS destination_city
            FROM SCHEDULE s
            JOIN BUS b ON s.bus_id = b.bus_id
            JOIN BUS_OPERATOR bo ON b.operator_id = bo.operator_id
            JOIN ROUTE r ON s.route_id = r.route_id
            JOIN CITY c1 ON r.source_city_id = c1.city_id
            JOIN CITY c2 ON r.destination_city_id = c2.city_id
            WHERE s.schedule_id = $1
        `, [scheduleId]);

        if (scheduleResult.rows.length === 0) {
            return res.status(404).json({ message: "Schedule not found" });
        }

        const scheduleDetails = scheduleResult.rows[0];

        // Get all seats with booking details
        const seatsResult = await pool.query(`
            SELECT 
                ss.seat_number,
                ss.schedule_seat_status,
                bs.passenger_name,
                bs.passenger_gender,
                u.name AS buyer_name,
                u.phone_number,
                u.email
            FROM SCHEDULE_SEAT ss

            LEFT JOIN (
                SELECT DISTINCT ON (bs.schedule_id, bs.seat_number)
                    bs.schedule_id,
                    bs.seat_number,
                    bs.passenger_name,
                    bs.passenger_gender,
                    bs.booking_id
                FROM BOOKED_SEAT bs
                JOIN BOOKING b ON bs.booking_id = b.booking_id
                WHERE b.booking_status = 'confirmed'
                ORDER BY bs.schedule_id, bs.seat_number, b.booking_time DESC
            ) bs
                ON ss.schedule_id = bs.schedule_id
                AND ss.seat_number = bs.seat_number

            LEFT JOIN BOOKING b 
                ON bs.booking_id = b.booking_id

            LEFT JOIN USERS u 
                ON b.user_id = u.user_id

            WHERE ss.schedule_id = $1 

            ORDER BY CAST(substr(ss.seat_number, 2) AS INTEGER)
        `, [scheduleId]);

        res.json({
            schedule: scheduleDetails,
            seats: seatsResult.rows
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Error fetching schedule details" });
    }
};
